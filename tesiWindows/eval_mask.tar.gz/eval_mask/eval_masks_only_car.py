from __future__ import print_function

import tensorflow as tf
import cv2
import numpy as np
import argparse
import os
from utils import *
from matplotlib import pyplot as plt

parser = argparse.ArgumentParser(description='Evaluation Masks Only on Cars')
### PATHS
parser.add_argument('--dataset', dest='dataset', choices=['kitti','cityscapes'], help='kitti,cityscapes')
parser.add_argument("--mask_gt_path", type=str, help="Path to dataset")
parser.add_argument("--semantic_gt_path", type=str, help="Path to dataset")
parser.add_argument("--pred_path",    type=str, help="Path to predictions")
parser.add_argument('--output_path',  type=str, default='results.txt', help='output results.txt')
parser.add_argument('--filename', default='filename.txt', help='Path to txt input list')
### PARAMS
parser.add_argument('--eval_probability', action='store_true' , help="eval motion probability instead of binary mask")
parser.add_argument('--th', type=float, help="threshold for motion probability")

parser.add_argument('--debug', action='store_true')
parser.add_argument('--car_label', type=int, default=13, help='label id of car objects')
parser.add_argument('--ignore_label', type=int, default=255, help='label id to ignore in evaluation')
parser.add_argument('--num_classes', dest='num_classes', type=int, default=2, help='# of classes')
args = parser.parse_args()

id2name = {0: 'dynamic', 1: 'static'}

prediction_placeholder = tf.placeholder(tf.int32)
prediction_placeholder.set_shape([None,None,1])
gt_placeholder = tf.placeholder(tf.int32)

gt = gt_placeholder
prediction = prediction_placeholder

### INIT WEIGHTS MIOU
weightsValue = tf.to_float(tf.not_equal(gt,args.ignore_label))
### IGNORE LABELS TO 0, WE HAVE ALREADY MASKED THOSE PIXELS WITH WEIGHTS 0###
gt = tf.where(tf.equal(gt, args.ignore_label), tf.zeros_like(gt), gt)
prediction = tf.where(tf.equal(prediction, args.ignore_label), tf.zeros_like(prediction), prediction)
### ACCURACY ###
acc, update_op_acc = tf.metrics.accuracy(gt,prediction,weights=weightsValue)
### MIOU ###
miou, update_op = tf.metrics.mean_iou(labels=tf.reshape(gt,[-1]),predictions=tf.reshape(prediction,[-1]), num_classes=args.num_classes, weights=tf.reshape(weightsValue,[-1]))

init_op = [tf.global_variables_initializer(), tf.local_variables_initializer()]

miou_value = 0
with tf.Session() as sess:
    sess.run(init_op)
    output_file = open(args.output_path, "w")
    lines = open(args.filename).readlines()
    lenght = len(lines)

    for idx,line in enumerate(sorted(lines)):
        gt_path = line.split(" ")[1].strip().replace(".jpg",".png")
        pred_path = os.path.join(args.pred_path, gt_path.replace("/","_"))
        sem_path = os.path.join(args.semantic_gt_path, gt_path)
        gt_path = os.path.join(args.mask_gt_path, gt_path)
        print("GT: ", gt_path, " Pred: ",  pred_path, " Sem: ", sem_path, idx, "/", lenght)#, end='\r')
        
        gt_value = cv2.imread(gt_path,cv2.IMREAD_GRAYSCALE)
        gt_value = np.where(gt_value == 0, np.ones_like(gt_value), np.zeros_like(gt_value)) # set to 0 dynamic object and rest to 1
        
        pred_value = cv2.imread(pred_path,cv2.IMREAD_GRAYSCALE) / 255 # [0-1]
        
        if args.eval_probability:
            pred_value = np.where(pred_value < args.th, np.zeros_like(pred_value), np.ones_like(pred_value)) # threshold

        sem_value = cv2.imread(sem_path,cv2.IMREAD_GRAYSCALE)
        gt_value[sem_value!=args.car_label] = args.ignore_label

        if args.debug:
            plt.subplot(3,1,1)
            plt.imshow(sem_value)
            plt.subplot(3,1,2)
            plt.imshow(gt_value)
            plt.subplot(3,1,3)
            plt.imshow(pred_value)
            plt.show()

        image_w = gt_value.shape[1]
        image_h = gt_value.shape[0]

        if pred_value.shape[0] != image_h or pred_value.shape[1] != image_w:
            #print("Resizing prediction ", pred_value.shape, " to GT ", gt_value.shape)
            pred_value = cv2.resize(pred_value, (image_w,image_h), interpolation=cv2.INTER_NEAREST)
        
        if args.dataset == 'cityscapes':
            crop_height = (image_h * 4) // 5
            gt_value  =  gt_value[:crop_height,:] 
            gt_value = cv2.resize(gt_value, (image_w,image_h), interpolation=cv2.INTER_NEAREST)

        _,_ =sess.run([update_op_acc,update_op],feed_dict={prediction_placeholder : np.expand_dims(pred_value,axis=-1) , gt_placeholder : np.expand_dims(gt_value,axis=-1)})
        acc_value, miou_value =sess.run([acc, miou],feed_dict={prediction_placeholder : np.expand_dims(pred_value,axis=-1) , gt_placeholder : np.expand_dims(gt_value,axis=-1)})
        
    confusion_matrix=tf.get_default_graph().get_tensor_by_name("mean_iou/total_confusion_matrix:0").eval()
    for cl in range(confusion_matrix.shape[0]):
        tp_fn = np.sum(confusion_matrix[cl,:])
        tp_fp = np.sum(confusion_matrix[:,cl])
        tp = confusion_matrix[cl,cl]
        if tp == 0 and (tp_fn + tp_fp - tp) == 0:
            IoU_cl = float('nan')
        else:
            IoU_cl = tp / (tp_fn + tp_fp - tp)
        output_file.write(id2name[cl] + ": {:.8f}".format(IoU_cl)+"\n")
        print(id2name[cl] + ": {:.8f}".format(IoU_cl))
    output_file.write("mIoU: " + str(miou_value) + " acc " + str(acc_value)+"\n")
    print("Only Cars: mIoU: " + str(miou_value) + " acc " + str(acc_value))
